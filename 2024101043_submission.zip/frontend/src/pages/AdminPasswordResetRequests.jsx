// Admin Password Reset Requests: Module level logic for the feature area.
import { useEffect, useState } from "react";
import api from "../lib/api";
import AdminNavbar from "../components/AdminNavbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

// Admin Password Reset Requests: Runs Admin password reset requests flow. Inputs: none. Returns: a function result.
export default function AdminPasswordResetRequests() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [requests, setRequests] = useState([]);
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [generatedCredentials, setGeneratedCredentials] = useState(null);

  const [reviewComment, setReviewComment] = useState("");

  // Load Data: Fetches the primary dataset for the current screen. Inputs: status. Returns: a function result.
  const loadData = async (status = statusFilter) => {
    setLoading(true);
    try {
      const requestsRes = await api.get("/admin/password-reset-requests", { params: { status } });
      setRequests(requestsRes.data?.requests || []);
    } catch (err) {
      setError(err.response?.data?.message || "Failed to load reset requests");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData("ALL");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Review Request: Records approval/rejection outcome and emits structured response text. Inputs: requestId, status. Returns: a function result.
  const reviewRequest = async (requestId, status) => {
    setError("");
    setMessage("");
    setGeneratedCredentials(null);
    try {
      const response = await api.patch(`/admin/password-reset-requests/${requestId}/review`, {
        status,
        adminComment: reviewComment || undefined,
      });
      setMessage(response.data?.message || "Request reviewed");
      setReviewComment("");
      setGeneratedCredentials(response.data?.generatedCredentials || null);
      await loadData();
    } catch (err) {
      setError(err.response?.data?.message || "Failed to review request");
    }
  };

  // Apply Filter: Applies filter to current state. Inputs: event. Returns: a function result.
  const applyFilter = async (event) => {
    event.preventDefault();
    await loadData(statusFilter);
  };

  return (
    <div className="space-y-4">
      <AdminNavbar />

      <Card>
        <CardHeader>
          <CardTitle>Password Reset Requests</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {error ? <p>{error}</p> : null}
          {message ? <p>{message}</p> : null}
          {loading ? <p>Loading...</p> : null}
        </CardContent>
      </Card>

      {generatedCredentials ? (
        <Card>
          <CardHeader>
            <CardTitle>Generated Temp Credentials (show once)</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Email: {generatedCredentials.email}</p>
            <p>Password: {generatedCredentials.password}</p>
          </CardContent>
        </Card>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Request List</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <form onSubmit={applyFilter} className="space-y-2">
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">ALL</SelectItem>
                <SelectItem value="PENDING">PENDING</SelectItem>
                <SelectItem value="APPROVED">APPROVED</SelectItem>
                <SelectItem value="REJECTED">REJECTED</SelectItem>
              </SelectContent>
            </Select>
            <Input
              placeholder="Admin comment for next review action"
              value={reviewComment}
              onChange={(e) => setReviewComment(e.target.value)}
            />
            <Button type="submit" variant="outline">
              Apply Status Filter
            </Button>
          </form>

          {requests.length === 0 ? (
            <p>No reset requests found.</p>
          ) : (
            requests.map((request) => (
              <Card key={request._id}>
                <CardContent className="space-y-1 pt-4">
                  <p>Organizer: {request.organizerId?.organizerName || "-"}</p>
                  <p>Email: {request.organizerId?.email || "-"}</p>
                  <p>Status: {request.status}</p>
                  <p>Reason: {request.reason}</p>
                  <p>Requested At: {new Date(request.requestedAt).toLocaleString()}</p>
                  <p>Admin Comment: {request.adminComment || "-"}</p>
                  {request.status === "PENDING" ? (
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => reviewRequest(request._id, "APPROVED")}
                      >
                        Approve
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => reviewRequest(request._id, "REJECTED")}
                      >
                        Reject
                      </Button>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}
