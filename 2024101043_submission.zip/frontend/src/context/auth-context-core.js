// Auth Context Core: Module level logic for the feature area.
import { createContext } from "react";

export const AuthContext = createContext(null);
