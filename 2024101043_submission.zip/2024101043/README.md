# Felicity Event Management System

Full-stack MERN application for participants, organizers, and admins to manage events, registrations, tickets, attendance, and merchandise.

## Stack
- Frontend: React + Vite
- Backend: Node.js + Express
- Database: MongoDB Atlas
- Auth: JWT (HTTP-only cookie)

## Repository Layout
- `backend/` API server, models, controllers, routes, middleware
- `frontend/` React SPA
- `deployment.txt` production deployment URLs

## Prerequisites
- Node.js `22.x`
- npm `10+`
- MongoDB Atlas connection string

## Environment Setup
1. Backend env file: `backend/.env`
2. Frontend env file (for local/dev or deployment platform env): `VITE_API_URL`

Required backend keys:
- `PORT`
- `MONGO_URI`
- `JWT_SECRET`
- `JWT_EXPIRES_IN`
- `ADMIN_EMAIL`
- `ADMIN_PASSWORD`
- `NODE_ENV`
- `FRONTEND_URL`
- `MAX_UPLOAD_MB`
- `EMAIL_FORCE_FAIL_SEND`
- `EMAIL_MODE` (`smtp` or `disabled`)
- `SMTP_HOST` (required when `EMAIL_MODE=smtp`)
- `SMTP_PORT` (required when `EMAIL_MODE=smtp`)
- `SMTP_SECURE` (required when `EMAIL_MODE=smtp`)
- `SMTP_USER` (required when `EMAIL_MODE=smtp`)
- `SMTP_PASS` (required when `EMAIL_MODE=smtp`)
- `SMTP_FROM` (required when `EMAIL_MODE=smtp`)

## Run Locally
1. Start backend:
```bash
cd backend
npm install
npm start
```
2. Start frontend:
```bash
cd frontend
npm install
npm run dev
```

## Useful Commands
1. Reset and seed database:
```bash
cd backend
npm run seed:reset
```
2. Build frontend:
```bash
cd frontend
npm run build
```

## Deployment
- Frontend and backend production links are stored in `deployment.txt`.
